﻿using System.Windows.Controls;

namespace $safeprojectname$.Views.Pages;

/// <summary>
/// Interaction logic for Dashboard.xaml
/// </summary>
public partial class Dashboard : Page
{
    public Dashboard()
    {
        InitializeComponent();
    }
}
