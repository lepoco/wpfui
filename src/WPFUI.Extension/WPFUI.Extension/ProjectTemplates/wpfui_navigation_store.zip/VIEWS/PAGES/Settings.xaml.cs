﻿using System.Windows.Controls;

namespace $safeprojectname$.Views.Pages;

/// <summary>
/// Interaction logic for Settings.xaml
/// </summary>
public partial class Settings : Page
{
    public Settings()
    {
        InitializeComponent();
    }
}
